import { buildForm } from "../utils/buildForm.js";



export default function updateTemplateHTML() {
    
}

export { updateTemplateHTML }